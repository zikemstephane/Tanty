import { Routes } from '@angular/router';
import { ProductionLayoutComponent } from '../../../layout/production-layout/production-layout.component';

export const PRODUCTION_ROUTES: Routes = [
  {
    path: '',
    component: ProductionLayoutComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadComponent: () => import('./pages/dashboard/production-dashboard.component').then(m => m.ProductionDashboardComponent) },
      { path: 'plan', loadComponent: () => import('./pages/plan/production-plan.component').then(m => m.ProductionPlanComponent) },
      { path: 'saisie', loadComponent: () => import('./pages/saisie/production-saisie.component').then(m => m.ProductionSaisieComponent) },
      { path: 'chef-machiniste', loadComponent: () => import('./pages/chef-machiniste/chef-machiniste.component').then(m => m.ChefMachinisteComponent) },
      { path: 'agent-doseur', loadComponent: () => import('./pages/agent-doseur/agent-doseur.component').then(m => m.AgentDoseurComponent) },
      { path: 'lots', loadComponent: () => import('./pages/lots/production-lots.component').then(m => m.ProductionLotsComponent) },
      { path: 'responsable-salle', loadComponent: () => import('./pages/responsable-salle/responsable-salle.component').then(m => m.ResponsableSalleComponent) },
      { path: 'employes', loadComponent: () => import('./pages/employes/production-employes.component').then(m => m.ProductionEmployesComponent) },
    ]
  }
];
