import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProductionService, PPHBE } from '../../../infrastructure/production.service';
import { fCFA } from '../../../../../shared/utils/format.utils';

@Component({
  selector: 'app-production-plan',
  standalone: true,
  imports: [CommonModule, DatePipe, DecimalPipe, RouterLink, FormsModule],
  templateUrl: './production-plan.component.html',
  styleUrls: ['./production-plan.component.css']
})
export class ProductionPlanComponent implements OnInit {
  today = new Date();
  fCFA = fCFA;
  private readonly prodSvc = inject(ProductionService);

  pph = signal<PPHBE | null>(null);
  pphs = signal<PPHBE[]>([]);
  loading = signal(true);
  message = signal('');

  showCreerPPH = signal(false);
  showModifierLignes = signal(false);
  nouveauPPH = { referenceBC: '', dateDebut: '', dateFin: '' };
  lignesModifiees: { codeProduit: string; nomProduit: string; objectifSemaine: number }[] = [];

  lignesMP = computed(() => {
    const p = this.pph();
    if (!p || !p.repartitionJours) return [] as { nom: string; quantite: number; unite: string }[];
    const totalMais = p.repartitionJours.reduce((s, j) => s + (j.poudreMaisKg || 0), 0);
    const totalSoja = p.repartitionJours.reduce((s, j) => s + (j.poudreSojaKg || 0), 0);
    const totalArachide = p.repartitionJours.reduce((s, j) => s + (j.poudreArachideKg || 0), 0);
    const lignes: { nom: string; quantite: number; unite: string }[] = [];
    if (totalMais > 0) lignes.push({ nom: 'Maïs', quantite: Math.round(totalMais * 100) / 100, unite: 'kg' });
    if (totalSoja > 0) lignes.push({ nom: 'Soja', quantite: Math.round(totalSoja * 100) / 100, unite: 'kg' });
    if (totalArachide > 0) lignes.push({ nom: 'Arachide', quantite: Math.round(totalArachide * 100) / 100, unite: 'kg' });
    return lignes;
  });

  totalMP = computed(() => this.lignesMP().length);

  totalProduitsPlannifies = computed(() => {
    const p = this.pph();
    if (!p || !p.lignes) return 0;
    return p.lignes.reduce((s, l) => s + (l.objectifSemaine || 0), 0);
  });
  totalProduitsRealises = computed(() => {
    const p = this.pph();
    if (!p || !p.lignes) return 0;
    return p.lignes.reduce((s, l) => s + (l.productionRealisee || 0), 0);
  });

  progressionGlobale = computed(() => {
    const total = this.totalProduitsPlannifies();
    if (total === 0) return 0;
    return Math.round((this.totalProduitsRealises() / total) * 100);
  });

  totalFuts = computed(() => {
    const p = this.pph();
    return p?.repartitionJours?.reduce((s, j) => s + (j.futsPrevus || 0), 0) ?? 0;
  });

  totalEmballages = computed(() => {
    const p = this.pph();
    return p?.repartitionJours?.reduce((s, j) => s + (j.sachetsPrevus || 0), 0) ?? 0;
  });

  getProduitDesignation(code: string): string {
    return code;
  }

  ngOnInit(): void {
    this.prodSvc.getPPHEnCours().subscribe({
      next: p => { this.pph.set(p); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
    this.prodSvc.getPPHs().subscribe({
      next: p => this.pphs.set(p)
    });
  }

  selectionnerPPH(ref: string): void {
    this.loading.set(true);
    this.prodSvc.getPPH(ref).subscribe({
      next: p => { this.pph.set(p); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  creerPPH(): void {
    this.prodSvc.creerPPH(this.nouveauPPH).subscribe({
      next: p => {
        this.pphs.update(list => [...list, p]);
        this.pph.set(p);
        this.showCreerPPH.set(false);
        this.nouveauPPH = { referenceBC: '', dateDebut: '', dateFin: '' };
      },
      error: () => this.message.set('Erreur lors de la création du PPH')
    });
  }

  validerPPH(): void {
    const ref = this.pph()?.referencePPH;
    if (!ref) return;
    this.prodSvc.validerPPH(ref).subscribe({
      next: p => this.pph.set(p),
      error: () => this.message.set('Erreur lors de la validation')
    });
  }

  demarrerPPH(): void {
    const ref = this.pph()?.referencePPH;
    if (!ref) return;
    this.prodSvc.demarrerPPH(ref).subscribe({
      next: p => this.pph.set(p),
      error: () => this.message.set('Erreur lors du démarrage')
    });
  }

  cloturerPPH(): void {
    const ref = this.pph()?.referencePPH;
    if (!ref) return;
    this.prodSvc.cloturerPPH(ref).subscribe({
      next: p => this.pph.set(p),
      error: () => this.message.set('Erreur lors de la clôture')
    });
  }

  ouvrirModifierLignes(): void {
    this.lignesModifiees = (this.pph()?.lignes || []).map(l => ({
      codeProduit: l.codeProduit, nomProduit: l.nomProduit, objectifSemaine: l.objectifSemaine
    }));
    this.showModifierLignes.set(true);
  }

  modifierLignes(): void {
    const ref = this.pph()?.referencePPH;
    if (!ref) return;
    this.prodSvc.modifierLignesPPH(ref, this.lignesModifiees).subscribe({
      next: p => { this.pph.set(p); this.showModifierLignes.set(false); },
      error: () => this.message.set('Erreur lors de la modification des lignes')
    });
  }

  progression(realise: number, prevu: number): number {
    if (prevu === 0) return 0;
    return Math.min(Math.round((realise / prevu) * 100), 100);
  }

  progressClass(pct: number): string {
    if (pct >= 100) return 'prog-bar prog-g';
    if (pct >= 60) return 'prog-bar prog-y';
    return 'prog-bar prog-r';
  }

  statutPlanClass(s: string): string {
    const map: Record<string, string> = {
      EN_COURS: 'badge bg-orange',
      CLOTURE: 'badge bg-success',
      VALIDE: 'badge bg-neutral',
      BROUILLON: 'badge bg-neutral',
    };
    return map[s] ?? 'badge bg-neutral';
  }
}
