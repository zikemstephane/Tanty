import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProductionService, LigneRegistreBE, PPHBE } from '../../../infrastructure/production.service';

@Component({
  selector: 'app-production-employes',
  standalone: true,
  imports: [CommonModule, DatePipe, RouterLink, FormsModule],
  templateUrl: './production-employes.component.html',
  styleUrls: ['./production-employes.component.css']
})
export class ProductionEmployesComponent implements OnInit {
  today = new Date();
  fCFA = (n: number) => new Intl.NumberFormat('fr-CM').format(Math.round(n)) + ' FCFA';

  private readonly svc = inject(ProductionService);

  employes = signal<LigneRegistreBE[]>([]);
  pphs = signal<PPHBE[]>([]);
  showEnregistrerRegistre = signal(false);
  message = signal('');

  referencePPH = '';
  dateRegistre = new Date().toISOString().split('T')[0];
  lignesRegistre: { matriculeEmploye: string; nomEmploye: string; poste: string; present: boolean; motifAbsence: string; heureArrivee: string; qteRealisee: number; unite: string }[] = [];

  nbPresents = computed(() =>
    this.employes().filter(e => e.present).length
  );

  nbAbsents = computed(() =>
    this.employes().filter(e => !e.present).length
  );

  tauxPresence = computed(() => {
    const total = this.employes().length;
    if (total === 0) return 0;
    return Math.round((this.nbPresents() / total) * 100);
  });

  postesDistincts = computed(() => {
    const postes = new Set(this.employes().map(e => e.poste));
    return postes.size;
  });

  presentsSeul = computed(() =>
    this.employes().filter(e => e.present)
  );

  ngOnInit(): void {
    this.svc.getRegistres().subscribe({
      next: (registres) => {
        if (registres.length > 0) {
          const latest = registres[0];
          this.employes.set(latest.lignes);
        }
      },
      error: () => {},
    });
    this.svc.getPPHs().subscribe({
      next: p => this.pphs.set(p)
    });
  }

  ouvrirEnregistrerRegistre(): void {
    this.lignesRegistre = [this.nouvelleLigneVide()];
    this.showEnregistrerRegistre.set(true);
  }

  ajouterLigne(): void {
    this.lignesRegistre = [...this.lignesRegistre, this.nouvelleLigneVide()];
  }

  retirerLigne(index: number): void {
    this.lignesRegistre = this.lignesRegistre.filter((_, i) => i !== index);
  }

  private nouvelleLigneVide() {
    return { matriculeEmploye: '', nomEmploye: '', poste: '', present: true, motifAbsence: '', heureArrivee: '', qteRealisee: 0, unite: 'kg' };
  }

  enregistrerRegistre(): void {
    const lignes = this.lignesRegistre.filter(l => l.matriculeEmploye.trim() && l.nomEmploye.trim());
    if (!this.referencePPH || lignes.length === 0) {
      this.message.set('Veuillez renseigner le PPH et au moins une ligne');
      return;
    }
    this.svc.enregistrerRegistre({
      referencePPH: this.referencePPH,
      date: this.dateRegistre,
      lignes
    }).subscribe({
      next: r => {
        this.employes.set(r.lignes);
        this.showEnregistrerRegistre.set(false);
        this.message.set('Registre enregistré');
      },
      error: () => this.message.set('Erreur lors de l\'enregistrement du registre')
    });
  }
}
