import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductionService, LotBE, PPHBE } from '../../../infrastructure/production.service';

interface LotUI {
  id: string; numeroLot: string; codeProduit: string; designation: string;
  declaredQuantityKg: number; equivalentUnits: number;
  dlc: Date; statut: string; dateDeclaration: Date;
  productionDate: Date; declaredBy: string;
}

@Component({
  selector: 'app-production-lots',
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule],
  templateUrl: './production-lots.component.html',
  styleUrls: ['./production-lots.component.css']
})
export class ProductionLotsComponent implements OnInit {
  private readonly svc = inject(ProductionService);

  today = new Date();
  fCFA = (n: number) => new Intl.NumberFormat('fr-CM').format(Math.round(n)) + ' FCFA';
  loading = signal(false);

  lots = signal<LotUI[]>([]);
  pphs = signal<PPHBE[]>([]);
  showDeclarerLot = signal(false);
  message = signal('');

  nouveauLot = {
    codeProduit: '', referencePPH: '', quantiteKg: 0, quantiteUnites: 0, dlc: ''
  };

  nbDeclares = computed(() => this.lots().filter(l => l.statut === 'DECLARED_BY_PRODUCTION' || l.statut === 'DECLARE').length);
  nbValidesStock = computed(() => this.lots().filter(l => l.statut === 'VALIDATED_BY_STOCK' || l.statut === 'VALIDE').length);
  totalKgDeclares = computed(() => this.lots().reduce((s, l) => s + l.declaredQuantityKg, 0));
  totalUnites = computed(() => this.lots().reduce((s, l) => s + l.equivalentUnits, 0));

  ngOnInit(): void {
    this.loading.set(true);
    this.svc.getLots().subscribe({
      next: list => { this.lots.set(list.map(this.mapL)); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
    this.svc.getPPHs().subscribe({
      next: p => this.pphs.set(p)
    });
  }

  declarerLot(): void {
    const req = { ...this.nouveauLot };
    if (!req.codeProduit || !req.referencePPH || req.quantiteKg <= 0) {
      this.message.set('Veuillez renseigner tous les champs obligatoires');
      return;
    }
    this.svc.declarerLot(req).subscribe({
      next: l => {
        this.lots.update(list => [this.mapL(l), ...list]);
        this.showDeclarerLot.set(false);
        this.nouveauLot = { codeProduit: '', referencePPH: '', quantiteKg: 0, quantiteUnites: 0, dlc: '' };
        this.message.set('');
      },
      error: () => this.message.set('Erreur lors de la déclaration du lot')
    });
  }

  getProduitDesignation(code: string): string {
    return this.lots().find(l => l.codeProduit === code)?.designation ?? code;
  }

  statutClass(s: string): string {
    return (s === 'VALIDATED_BY_STOCK' || s === 'VALIDE') ? 'badge bg-success' : 'badge bg-orange';
  }

  statutLabel(s: string): string {
    return (s === 'VALIDATED_BY_STOCK' || s === 'VALIDE') ? 'Validé Stock' : 'Déclaré Production';
  }

  private mapL(l: LotBE): LotUI {
    const date = new Date(l.dateDeclaration);
    return {
      id: l.numeroLot,
      numeroLot: l.numeroLot,
      codeProduit: l.codeProduit,
      designation: l.designationProduit,
      declaredQuantityKg: l.quantiteKg,
      equivalentUnits: l.quantiteUnites,
      dlc: new Date(l.dlc),
      statut: l.statut,
      dateDeclaration: date,
      productionDate: date,
      declaredBy: l.matriculeDeclarant,
    };
  }
}
