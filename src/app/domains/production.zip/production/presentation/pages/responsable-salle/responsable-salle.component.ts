import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductionService, AffectationBE, FicheProductionBE, PPHBE } from '../../../infrastructure/production.service';
import { finalize } from 'rxjs';

@Component({
  selector: 'app-responsable-salle',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './responsable-salle.component.html',
  styleUrls: ['./responsable-salle.component.css']
})
export class ResponsableSalleComponent implements OnInit {
  private readonly service = inject(ProductionService);
  private readonly router = inject(Router);

  pphs: PPHBE[] = [];
  selectedPph: PPHBE | null = null;
  affectation: AffectationBE | null = null;
  fiche: FicheProductionBE | null = null;
  date = new Date().toISOString().split('T')[0];
  isLoading = false;
  error: string | null = null;
  success: string | null = null;

  tab: 'affectation' | 'saisie' | 'fiche' | 'classement' | 'rapport' = 'affectation';

  nouvelleAffectation: { codePoste: string; matricule: string }[] = [];

  ngOnInit() {
    this.chargerPPHs();
  }

  chargerPPHs() {
    this.isLoading = true;
    this.service.getPPHs()
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: pphs => this.pphs = pphs,
        error: err => this.error = 'Erreur chargement PPH : ' + (err?.message ?? err)
      });
  }

  selectionnerPph(pph: PPHBE) {
    this.selectedPph = pph;
    this.chargerAffectation(pph.referenceBC);
    this.chargerFiche(pph.referenceBC, this.date);
  }

  chargerAffectation(referencePPH: string) {
    this.isLoading = true;
    this.service.getAffectationDuJour(referencePPH)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: a => this.affectation = a,
        error: err => {
          this.affectation = null;
          this.error = 'Aucune affectation trouvée pour ce jour : ' + (err?.message ?? err);
        }
      });
  }

  chargerFiche(referencePPH: string, date: string) {
    this.service.getFiche(referencePPH, date).subscribe({
      next: f => this.fiche = f,
      error: () => this.fiche = null
    });
  }

  creerAffectation() {
    if (!this.selectedPph || this.nouvelleAffectation.length === 0) return;
    const lignes = this.nouvelleAffectation.map(l => ({ ...l, duree: 'PT8H' }));
    this.service.creerAffectation({
      referencePPH: this.selectedPph.referenceBC,
      date: this.date,
      matriculeAgent: 'RS-001',
      lignes
    }).subscribe({
      next: a => {
        this.affectation = a;
        this.success = 'Affectation créée.';
        this.nouvelleAffectation = [];
      },
      error: err => this.error = 'Erreur création affectation : ' + (err?.message ?? err)
    });
  }

  ajouterLigneAffectation() {
    this.nouvelleAffectation.push({ codePoste: '', matricule: '' });
  }

  saisirRealisation(codePoste: string) {
    const saisie = prompt('Quantité réalisée pour ' + codePoste);
    if (!saisie || !this.affectation) return;
    const qte = Number(saisie);
    if (Number.isNaN(qte)) return;

    this.service.saisirRealisationPoste({
      affectationId: this.affectation.id,
      codePoste,
      quantiteRealisee: qte,
      productionsIndividuelles: []
    }).subscribe({
      next: a => {
        this.affectation = a;
        this.success = 'Réalisation enregistrée.';
      },
      error: err => this.error = 'Erreur saisie : ' + (err?.message ?? err)
    });
  }

  enregistrerFiche() {
    if (!this.selectedPph || !this.fiche) return;
    this.service.enregistrerFiche({
      referencePPH: this.selectedPph.referenceBC,
      semaine: this.selectedPph.semaine,
      date: this.date,
      matriculeAgentProduction: 'RS-001',
      lignes: this.fiche.lignes,
      predictionDosage: this.fiche.predictionDosage,
      predictionPostes: this.fiche.predictionPostes
    }).subscribe({
      next: f => {
        this.fiche = f;
        this.success = 'Fiche enregistrée.';
      },
      error: err => this.error = 'Erreur fiche : ' + (err?.message ?? err)
    });
  }

  allerEmployes() {
    this.router.navigate(['/production/employes']);
  }

  trackByIndex(index: number) { return index; }
}
