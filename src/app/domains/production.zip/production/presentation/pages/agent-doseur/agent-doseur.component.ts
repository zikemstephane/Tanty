import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import {
  ProductionService, SessionDosageBE, StatistiquesFutsBE, PredictionProduitFiniBE
} from '../../../infrastructure/production.service';

@Component({
  selector: 'app-agent-doseur',
  standalone: true,
  imports: [CommonModule, DatePipe, DecimalPipe, FormsModule, RouterLink],
  templateUrl: './agent-doseur.component.html',
  styleUrls: ['./agent-doseur.component.css']
})
export class AgentDoseurComponent implements OnInit {
  private readonly prodSvc = inject(ProductionService);

  today = new Date().toISOString().split('T')[0];
  semaineDebut = signal(this.debutSemaine(new Date()));
  semaineFin = signal(this.today);
  moisDebut = signal(this.debutMois(new Date()));
  moisFin = signal(this.today);

  sessions = signal<SessionDosageBE[]>([]);
  statsHebdo = signal<StatistiquesFutsBE | null>(null);
  statsMois = signal<StatistiquesFutsBE | null>(null);
  prediction = signal<PredictionProduitFiniBE | null>(null);
  loading = signal(true);

  selectedSession = signal<SessionDosageBE | null>(null);
  showFormSession = signal(false);

  nouvelleSession = { referencePPH: '', date: this.today, matriculeAgentDoseur: '' };
  nouvelleMatiere = { typeMatiere: 'MAIS', quantiteKg: 0 };
  nouvelleMachine = '';
  futs = { nbProduits: 0, nbCasses: 0 };
  nbFutsPrediction = 0;

  matieresDisponibles = ['MAIS', 'SOJA', 'ARACHIDE', 'SUCRE', 'POISSON'];

  totalFutsJour = computed(() =>
    this.sessions().filter(s => s.date === this.today).reduce((s, sess) => s + sess.futsNets, 0)
  );

  totalFutsCassesJour = computed(() =>
    this.sessions().filter(s => s.date === this.today).reduce((s, sess) => s + sess.futsCasses, 0)
  );

  sessionsActives = computed(() => this.sessions().filter(s => !s.cloturee));

  ngOnInit(): void {
    this.chargerDonnees();
  }

  chargerDonnees(): void {
    this.loading.set(true);
    this.prodSvc.getSessionsDosageParDate(this.today).subscribe({
      next: s => { this.sessions.set(s); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.prodSvc.getStatistiquesFuts(this.semaineDebut(), this.semaineFin()).subscribe({
      next: r => this.statsHebdo.set(r)
    });
    this.prodSvc.getStatistiquesFuts(this.moisDebut(), this.moisFin()).subscribe({
      next: r => this.statsMois.set(r)
    });
  }

  ouvrirSession(): void {
    this.prodSvc.ouvrirSessionDosage(this.nouvelleSession).subscribe({
      next: s => { this.sessions.update(list => [s, ...list]); this.showFormSession.set(false); }
    });
  }

  ajouterMatiere(session: SessionDosageBE): void {
    this.prodSvc.enregistrerMatiereDosage(session.id, this.nouvelleMatiere.typeMatiere, this.nouvelleMatiere.quantiteKg)
      .subscribe({
        next: s => this.sessions.update(list => list.map(x => x.id === s.id ? s : x))
      });
  }

  ajouterMachine(session: SessionDosageBE): void {
    if (!this.nouvelleMachine.trim()) return;
    this.prodSvc.enregistrerMachineDosage(session.id, this.nouvelleMachine.trim()).subscribe({
      next: s => { this.sessions.update(list => list.map(x => x.id === s.id ? s : x)); this.nouvelleMachine = ''; }
    });
  }

  enregistrerFuts(session: SessionDosageBE): void {
    this.prodSvc.enregistrerFutsDosage(session.id, this.futs.nbProduits, this.futs.nbCasses).subscribe({
      next: s => this.sessions.update(list => list.map(x => x.id === s.id ? s : x))
    });
  }

  cloturerSession(session: SessionDosageBE): void {
    if (!confirm('Clôturer définitivement cette session de dosage ?')) return;
    this.prodSvc.cloturerSessionDosage(session.id).subscribe({
      next: s => this.sessions.update(list => list.map(x => x.id === s.id ? s : x))
    });
  }

  justifierEcart(session: SessionDosageBE): void {
    const motif = prompt('Justification de l\'écart :');
    if (motif) {
      this.prodSvc.justifierEcartDosage(session.id, motif).subscribe({
        next: s => this.sessions.update(list => list.map(x => x.id === s.id ? s : x))
      });
    }
  }

  lancerPrediction(): void {
    if (this.nbFutsPrediction <= 0) return;
    this.prodSvc.predireProduitFini(this.nbFutsPrediction).subscribe({
      next: p => this.prediction.set(p)
    });
  }

  telechargerRegistre(session: SessionDosageBE, format: 'pdf' | 'excel'): void {
    this.prodSvc.telechargerRegistreDosage(session.id, format).subscribe({
      next: blob => this.declencherTelechargement(blob, `registre-dosage-${session.id}.${format === 'excel' ? 'xlsx' : 'pdf'}`)
    });
  }

  telechargerDocuments(session: SessionDosageBE): void {
    this.prodSvc.telechargerDocumentsDosage(session.id).subscribe({
      next: blob => this.declencherTelechargement(blob, `documents-dosage-${session.id}.zip`)
    });
  }

  private declencherTelechargement(blob: Blob, nom: string): void {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = nom;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  private debutSemaine(d: Date): string {
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.setDate(diff)).toISOString().split('T')[0];
  }

  private debutMois(d: Date): string {
    return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().split('T')[0];
  }
}
