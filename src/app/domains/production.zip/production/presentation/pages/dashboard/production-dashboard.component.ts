import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import {
  ProductionService, LotBE, OFBE, PPHBE, DashboardChefBE
} from '../../../infrastructure/production.service';

interface LotDashUI {
  id: string; codeProduit: string; designationProduit: string;
  declaredQuantityKg: number; statut: string;
}

interface OrdreUI {
  id: string; referencePPH: string; designation: string; qteDemandee: number;
  qteRealisee: number; dateButoir: Date; statut: string;
}

interface LignePlanUI { codeProduit: string; qtePrevue: number; qteRealisee: number; }

interface PlanUI {
  semaine: string; dateDebut: string; dateFin: string;
  chefProduction: string; statut: string;
  lignesProduitsFinis: LignePlanUI[];
}

interface EmployeUI { id: string; nom: string; poste: string; present: boolean; }

@Component({
  selector: 'app-production-dashboard',
  standalone: true,
  imports: [CommonModule, DatePipe, RouterLink, FormsModule],
  templateUrl: './production-dashboard.component.html',
  styleUrls: ['./production-dashboard.component.css']
})
export class ProductionDashboardComponent implements OnInit {
  private readonly svc = inject(ProductionService);

  today = new Date();
  fCFA = (n: number) => new Intl.NumberFormat('fr-CM').format(Math.round(n)) + ' FCFA';
  Math = Math;
  loading = signal(true);

  lots = signal<LotDashUI[]>([]);
  ordres = signal<OrdreUI[]>([]);
  pphs = signal<PPHBE[]>([]);

  plan = signal<PlanUI>({
    semaine: '—', dateDebut: '—', dateFin: '—',
    chefProduction: '—', statut: '—', lignesProduitsFinis: [],
  });
  employes = signal<EmployeUI[]>([]);
  kpi = {
    quantiteProduiteKg: 0, quantiteConditionneeCartons: 0,
    rendementMatiere: 0, tauxRebut: 0, trs: 0,
    productiviteHoraire: 0, valorisationJour: 0,
  };
  carburant: { id: string; immatriculation: string; litresDemandes: number; montant: number; statut: string }[] = [];
  maintenance: { equipement: string; etat: string; prochaineMaint?: Date }[] = [];
  variance: { poste: string; standard: number; reel: number; unite: string }[] = [];

  dashboard = signal<DashboardChefBE | null>(null);

  nbPresents = computed(() => this.employes().filter(e => e.present).length);
  nbLotsDeclares = computed(() => this.lots().filter(l => l.statut === 'DECLARE').length);
  nbLotsValides = computed(() => this.lots().filter(l => l.statut === 'VALIDE').length);
  maintenanceAlertes = computed(() => this.maintenance.filter(m => m.etat !== 'OPERATIONNEL').length);

  ofEnCours = computed(() => this.dashboard()?.ofsEnCours ?? this.ordres().filter(o => o.statut === 'EN_COURS').length);
  ofPlanifies = computed(() => this.dashboard()?.ofsPlanifies ?? this.ordres().filter(o => o.statut === 'PLANIFIE').length);
  ofHonores = computed(() => this.dashboard()?.ofsHonores ?? this.ordres().filter(o => o.statut === 'HONORE').length);
  tauxCharge = computed(() => {
    const ofs = this.ordres();
    const dem = ofs.reduce((s, o) => s + o.qteDemandee, 0);
    const rea = ofs.reduce((s, o) => s + o.qteRealisee, 0);
    return dem ? Math.round((rea / dem) * 100) : 0;
  });
  lotsEnAttente = computed(() => this.dashboard()?.lotsEnAttenteValidation ?? 0);
  tauxAvancementPPH = computed(() => this.dashboard()?.tauxAvancementPPH ?? 0);
  pphEnCoursReference = computed(() => this.dashboard()?.pphEnCoursReference ?? null);

  showCreerOF = signal(false);
  showProduireOF = signal<string | null>(null);
  nouveauOF = {
    idOF: '', referencePPH: '', codeProduit: '', designationProduit: '', qteDemandee: 0, dateButoir: ''
  };
  quantiteProduire = 0;

  carburantAValider(): number {
    return this.carburant.filter(c => c.statut !== 'VALIDEE').length;
  }

  ngOnInit(): void {
    this.chargerDonnees();
  }

  private chargerDonnees(): void {
    this.loading.set(true);
    forkJoin({
      lots: this.svc.getLots(),
      ofs: this.svc.getOFs(),
      dashboard: this.svc.getDashboardChef(),
      pphs: this.svc.getPPHs(),
    }).subscribe({
      next: ({ lots, ofs, dashboard, pphs }) => {
        this.lots.set(lots.map(l => ({
          id: l.numeroLot,
          codeProduit: l.codeProduit,
          designationProduit: l.designationProduit,
          declaredQuantityKg: l.quantiteKg,
          statut: l.statut,
        })));
        this.ordres.set(ofs.map(o => ({
          id: o.id,
          referencePPH: o.referencePPH,
          designation: o.designation,
          qteDemandee: o.quantiteDemandee,
          qteRealisee: o.quantiteRealisee,
          dateButoir: new Date(o.dateFin ?? o.dateCreation),
          statut: o.statut,
        })));
        this.dashboard.set(dashboard);
        this.pphs.set(pphs);
        this.kpi.quantiteProduiteKg = dashboard.quantiteKgSemaine;
        this.kpi.quantiteConditionneeCartons = dashboard.cartonsSemaine;
        this.plan.update(p => ({
          ...p,
          semaine: dashboard.pphEnCoursSemaine ?? p.semaine,
        }));
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  creerOF(): void {
    const req = { ...this.nouveauOF, dateButoir: this.nouveauOF.dateButoir || undefined };
    this.svc.creerOF(req).subscribe({
      next: o => {
        this.ordres.update(list => [...list, {
          id: o.id, referencePPH: o.referencePPH, designation: o.designation,
          qteDemandee: o.quantiteDemandee, qteRealisee: o.quantiteRealisee,
          dateButoir: new Date(o.dateFin ?? o.dateCreation), statut: o.statut
        }]);
        this.showCreerOF.set(false);
        this.nouveauOF = { idOF: '', referencePPH: '', codeProduit: '', designationProduit: '', qteDemandee: 0, dateButoir: '' };
      }
    });
  }

  demarrerOF(idOF: string): void {
    this.svc.demarrerOF(idOF).subscribe({
      next: o => this.mettreAJourOF(o)
    });
  }

  annulerOF(idOF: string): void {
    if (!confirm('Annuler cet ordre de fabrication ?')) return;
    this.svc.annulerOF(idOF).subscribe({
      next: o => this.mettreAJourOF(o)
    });
  }

  ouvrirProduire(idOF: string): void {
    this.showProduireOF.set(idOF);
    this.quantiteProduire = 0;
  }

  produireOF(idOF: string): void {
    if (this.quantiteProduire <= 0) return;
    this.svc.produireOF(idOF, this.quantiteProduire).subscribe({
      next: o => { this.mettreAJourOF(o); this.showProduireOF.set(null); }
    });
  }

  private mettreAJourOF(o: OFBE): void {
    this.ordres.update(list => list.map(x => x.id === o.id ? {
      ...x,
      qteRealisee: o.quantiteRealisee,
      statut: o.statut,
      dateButoir: new Date(o.dateFin ?? o.dateCreation)
    } : x));
  }

  getProduitDesignation(code: string): string {
    return this.lots().find(l => l.codeProduit === code)?.designationProduit ?? code;
  }

  progression(realise: number, prevu: number): number {
    if (prevu === 0) return 0;
    return Math.min(Math.round((realise / prevu) * 100), 100);
  }

  progressClass(pct: number): string {
    if (pct >= 100) return 'prog-bar prog-g';
    if (pct >= 60) return 'prog-bar prog-y';
    return 'prog-bar prog-r';
  }
}
